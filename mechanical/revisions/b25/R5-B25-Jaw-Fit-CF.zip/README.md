# B25 PETG-CF 일체형 턱 맞춤 옵션

PETG-CF로 출력한 B25 맞춤 게이지의 H4 줄에 실제 Ø4 핀을 대 보고 같은 모델
지름의 3MF 하나를 고릅니다. Bambu Studio에서 프로젝트로 열고 본 출력과
같은 P2S 0.4 mm 경화 노즐, PETG-CF, 0.20 mm 층, Textured PEI로 출력합니다.
필라멘트를 65 °C에서 8시간 건조하고, 미리보기에서 8 mm 외곽 브림과
2층 래프트를 확인합니다. 출력물은 조립 전에 실물 핀으로 다시 맞춥니다.

눈틀과 눈꺼풀용 STL, PETG HF 턱 3MF는 기존 fit-c-variants.zip에 있습니다.
